# controlPosition
`controlPosition` allows you to set the elements to be dropped on the stage to either the left or right side.

## Usage
```javascript
var options = {
      controlPosition: 'left'
    };
$(container).formBuilder(options);
```


## See it in Action
<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="bpRBVL" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
